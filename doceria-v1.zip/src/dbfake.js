var db = {
    dados: [
        {
            titulo: 'Copão de Brownie com Oreo',
            descricao: 'Um copo que mescla o sabor do creme de chocolate, com brownie, uma mousse de Oreo bem leve, mousse de ninho e chantininho pra completar.',
            imagem: 'http://lorempixel.com/200/120/food/1',
            categoria: 'Copões de Brownie ',
            preco: 18.00
        }, {
            titulo: 'Pão de Mel',
            descricao: 'Pão de mel macio com recheio de doce de leite e cobertura de chocolate .',
            imagem: 'http://lorempixel.com/200/120/food/2',
            categoria: 'Indispensáveis',
            preco: 6.00
        }, {
            titulo: 'Brownie',
            descricao: 'Saboroso quadrado de brownie recheado. Sabores: Brigadeiro de Ninho, Ninho com nutella, Brigadeiro preto, Preto com nutella, Brigadeiro de ovomaltine, Brigadeiro duo(ninho/preto), Doce de leite.',
            imagem: 'http://lorempixel.com/200/120/food/3',
            categoria: 'Indispensáveis',
            preco: 6.50
        }, {
            titulo: 'Mousse de Ninho com Mousse de Nutella',
            descricao: 'Um show de mousse de nutella com mousse de ninho, amendoim e nutella.',
            imagem: 'http://lorempixel.com/200/120/food/4',
            categoria: 'Tortinhas',
            preco: 14.00
        }, {
            titulo: 'Água',
            descricao: 'Água mineral.',
            imagem: 'http://lorempixel.com/200/120/food/5',
            categoria: 'Bebidas',
            preco: 2.00
        }
    ]
}